//! Monitors and the app's windows (operator, room output, stage display).
//! Each output runs in its own Microsoft Edge app window with its own profile
//! folder, so it is a separate browser process from the operator window.
use serde::Serialize;
use std::{path::{Path, PathBuf}, process::Child};

#[derive(Serialize, Clone, Debug, PartialEq)]
pub struct Monitor {
    /// Windows device name, e.g. `\\.\DISPLAY2`. Used as the role binding.
    pub id: String,
    pub label: String,
    pub x: i32,
    pub y: i32,
    pub width: i32,
    pub height: i32,
    pub primary: bool,
}

#[cfg(windows)]
pub fn monitors() -> Vec<Monitor> {
    use windows_sys::Win32::{Foundation::{LPARAM, RECT}, Graphics::Gdi::*};
    unsafe extern "system" fn cb(h: HMONITOR, _: HDC, _: *mut RECT, data: LPARAM) -> i32 {
        let list = unsafe { &mut *(data as *mut Vec<Monitor>) };
        let mut info: MONITORINFOEXW = unsafe { std::mem::zeroed() };
        info.monitorInfo.cbSize = std::mem::size_of::<MONITORINFOEXW>() as u32;
        if unsafe { GetMonitorInfoW(h, &mut info as *mut MONITORINFOEXW as *mut MONITORINFO) } != 0 {
            let r = info.monitorInfo.rcMonitor;
            let len = info.szDevice.iter().position(|c| *c == 0).unwrap_or(info.szDevice.len());
            let id = String::from_utf16_lossy(&info.szDevice[..len]);
            let primary = info.monitorInfo.dwFlags & 1 != 0;
            let n = list.len() + 1;
            list.push(Monitor { label: format!("Screen {n}{}", if primary { " (this laptop / main)" } else { "" }), id, x: r.left, y: r.top, width: r.right - r.left, height: r.bottom - r.top, primary });
        }
        1
    }
    let mut list: Vec<Monitor> = vec![];
    unsafe {
        // Physical pixels, so positions are right on mixed-scaling setups.
        windows_sys::Win32::UI::WindowsAndMessaging::SetProcessDPIAware();
        EnumDisplayMonitors(std::ptr::null_mut(), std::ptr::null(), Some(cb), &mut list as *mut _ as LPARAM);
    }
    // Number screens left-to-right, like Windows' Display settings usually do.
    list.sort_by_key(|m| (m.x, m.y));
    for (i, m) in list.iter_mut().enumerate() {
        m.label = format!("Screen {}{} — {}×{}", i + 1, if m.primary { " (main)" } else { "" }, m.width, m.height);
    }
    list
}

#[cfg(not(windows))]
pub fn monitors() -> Vec<Monitor> {
    vec![Monitor { id: "main".into(), label: "Screen 1 (main) — 1920×1080".into(), x: 0, y: 0, width: 1920, height: 1080, primary: true }]
}

pub fn edge_path() -> Option<PathBuf> {
    if !cfg!(windows) { return None; }
    let mut c = vec![];
    for var in ["ProgramFiles(x86)", "ProgramFiles", "LOCALAPPDATA"] {
        if let Some(base) = std::env::var_os(var) { c.push(PathBuf::from(base).join(r"Microsoft\Edge\Application\msedge.exe")); }
    }
    c.into_iter().find(|p| p.is_file())
}

pub struct Window {
    child: Child,
    pub monitor: Option<String>,
    pub opened: std::time::Instant,
}

impl Window {
    pub fn alive(&mut self) -> bool { matches!(self.child.try_wait(), Ok(None)) }
    pub fn close(mut self) { let _ = self.child.kill(); let _ = self.child.wait(); }
}

/// Open `url` as a chromeless app window. `on` = put it full-screen on that monitor.
pub fn open_app_window(url: &str, profile: &Path, on: Option<&Monitor>) -> Result<Window, String> {
    let Some(edge) = edge_path() else {
        open_default_browser(url);
        return Err("Microsoft Edge was not found, so the page opened in your normal browser. Press F11 there for full screen.".into());
    };
    let mut args: Vec<String> = vec![
        format!("--app={url}"),
        format!("--user-data-dir={}", profile.display()),
        "--no-first-run".into(), "--no-default-browser-check".into(), "--disable-session-crashed-bubble".into(),
        "--autoplay-policy=no-user-gesture-required".into(), "--disable-features=Translate,msEdgeTranslate,msUndersideButton,msEdgeSidebarV2".into(),
        "--overscroll-history-navigation=0".into(), "--disable-pinch".into(), "--noerrdialogs".into(), "--hide-crash-restore-bubble".into(),
    ];
    if let Some(m) = on {
        // Aim at the middle of the screen so mixed display scaling still lands on the right monitor.
        args.push(format!("--window-position={},{}", m.x + m.width / 4, m.y + m.height / 4));
        args.push(format!("--window-size={},{}", (m.width / 2).max(400), (m.height / 2).max(300)));
        args.push("--start-fullscreen".into());
    } else {
        args.push("--window-size=1500,900".into());
    }
    let child = std::process::Command::new(edge).args(&args).spawn().map_err(|e| format!("Could not open Edge: {e}"))?;
    Ok(Window { child, monitor: on.map(|m| m.id.clone()), opened: std::time::Instant::now() })
}

pub fn open_default_browser(url: &str) {
    #[cfg(windows)]
    {
        use std::os::windows::process::CommandExt;
        let _ = std::process::Command::new("rundll32.exe").args(["url.dll,FileProtocolHandler", url]).creation_flags(0x08000000).spawn();
    }
    #[cfg(target_os = "linux")]
    { let _ = std::process::Command::new("xdg-open").arg(url).spawn(); }
    #[cfg(target_os = "macos")]
    { let _ = std::process::Command::new("open").arg(url).spawn(); }
}
