use rustypresenter::{server::{self, App}, store::Store};
use std::{net::{SocketAddr, UdpSocket}, sync::Arc, time::Duration};

fn pause_and_exit(msg: &str) -> ! {
    eprintln!("\n{msg}\n\nPress Enter to close.");
    let _ = std::io::stdin().read_line(&mut String::new());
    std::process::exit(1);
}

#[tokio::main]
async fn main() {
    let port: u16 = std::env::var("RUSTYPRESENTER_PORT").ok().and_then(|p| p.parse().ok()).unwrap_or(4318);
    let headless = std::env::args().any(|a| a == "--no-open");
    let Some(root) = server::data_dir() else { pause_and_exit("Cannot find a folder to keep your data in. Set RUSTYPRESENTER_DATA.") };

    // Already running? Just bring up its operator window.
    let listener = match tokio::net::TcpListener::bind((std::net::Ipv4Addr::UNSPECIFIED, port)).await {
        Ok(l) => l,
        Err(_) => {
            if !headless {
                let url = format!("http://127.0.0.1:{port}/");
                let _ = rustypresenter::displays::open_app_window(&url, &root.join("edge").join("operator"), None);
            }
            println!("RustyPresenter is already running.");
            return;
        }
    };

    let store = match Store::open(root.clone()) { Ok(s) => s, Err(e) => pause_and_exit(&format!("Cannot use the data folder {}: {e}", root.display())) };
    store.clean_tmp();
    let data = match store.load() { Ok(d) => d, Err(e) => pause_and_exit(&e) };
    let first_run = !store.data_path().exists();
    if first_run { let _ = store.save(&data); }

    let lan_ip = UdpSocket::bind("0.0.0.0:0").ok().and_then(|s| { s.connect("192.0.2.1:80").ok()?; s.local_addr().ok().map(|a| a.ip()) });
    let lan_url = lan_ip.map(|ip| format!("http://{ip}:{port}/remote"));
    let app = App::new(store, data, port, lan_url.clone());

    // A complete backup at every start, then daily.
    {
        let app = app.clone();
        tokio::spawn(async move {
            loop {
                let data = app.data.lock().unwrap().clone();
                if !data.songs.is_empty() || data.services.iter().any(|s| !s.items.is_empty()) {
                    if let Err(e) = app.store.backup(&data) { eprintln!("Backup failed: {e}"); }
                }
                tokio::time::sleep(Duration::from_secs(24 * 3600)).await;
            }
        });
    }
    tokio::spawn(app.clone().watchdog());

    println!("\n  RustyPresenter {}\n", env!("CARGO_PKG_VERSION"));
    println!("  Operator:      http://127.0.0.1:{port}/");
    if let Some(u) = &lan_url { println!("  Phone remote:  {u}"); }
    println!("  Your data:     {}", root.display());
    println!("\n  Keep this window open while presenting. Close it (or press Ctrl+C) to quit.\n");

    if !headless {
        if let Err(e) = app.open_window("operator", None) { eprintln!("{e}"); }
        // Reopen the room/stage screens where they were last time, if those screens are plugged in.
        let roles = app.data.lock().unwrap().settings.displays.clone();
        let mons = rustypresenter::displays::monitors();
        for (role, id) in [("room", roles.room), ("stage", roles.stage)] {
            if let Some(id) = id { if mons.iter().any(|m| m.id == id && !m.primary) { let _ = app.open_window(role, Some(&id)); } }
        }
    }

    let svc = server::router(app.clone()).into_make_service_with_connect_info::<SocketAddr>();
    let shutdown = async { let _ = tokio::signal::ctrl_c().await; };
    if let Err(e) = axum::serve(listener, svc).with_graceful_shutdown(shutdown).await { eprintln!("Server stopped: {e}"); }
    for role in ["room", "stage", "operator"] { app.close_window(role); }
}
