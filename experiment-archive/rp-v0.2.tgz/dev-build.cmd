@echo off
rem Builds and tests RustyPresenter, writing everything to build.log (for collaborators).
setlocal
cd /d "%~dp0"
if exist "%~dp0.tools\cargo\bin\cargo.exe" (
  set "CARGO_HOME=%~dp0.tools\cargo"
  set "RUSTUP_HOME=%~dp0.tools\rustup"
  set "PATH=%~dp0.tools\cargo\bin;%PATH%"
)
set "CARGO_TARGET_DIR=%LOCALAPPDATA%\RustyPresenter\build"
set "CARGO_TERM_COLOR=never"
echo BUILD STARTED %DATE% %TIME% > build.log
cargo build --release >> build.log 2>&1
echo BUILD EXIT %ERRORLEVEL% >> build.log
cargo test --release >> build.log 2>&1
echo TEST EXIT %ERRORLEVEL% >> build.log
echo BUILD FINISHED %DATE% %TIME% >> build.log
